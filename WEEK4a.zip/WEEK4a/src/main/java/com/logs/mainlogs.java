/** 
 * Creating log function to store logs using sql
 * This program is an integration towards accessing the objects of book class
 * this program is forming getters and setters in terms of POJO class and to ensure safety 
 * 
 * Note: Getters and Setters have been generated generated and to string method is used to overide the method. 
 *  
 * @author Ramkrishna Dakwa (Great Learning FSD 10th Batch)
 * @version 17.0 
 * @since 2nd April 2022 
 */
package com.logs;

import java.util.logging.Level;

import com.google.protobuf.Extension.MessageType;

import java.io.IOException;
import java.util.*;

public class mainlogs {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		log mylog = new log("log.txt");
//	java.lang.System.Logger.Level level = Level.WARNING ; // using log function to store logs
//  mylog.logger.log(level,"Warning");//is
	}

	private static java.lang.System.Logger.Level MessageType(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
